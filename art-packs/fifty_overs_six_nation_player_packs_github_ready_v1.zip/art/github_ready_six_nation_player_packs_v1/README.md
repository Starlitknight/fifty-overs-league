# Fifty Overs — Six-Nation Player Packs (GitHub Runtime Edition)

Optimized runtime artwork for the six expansion clubs:

- Afghanistan
- Ireland
- Netherlands
- Pakistan
- Sri Lanka
- Zimbabwe

Each nation folder contains nine 512 × 512 WebP player assets:

1. Batter
2. Wicketkeeper
3. Seam all-rounder
4. Spin all-rounder
5. Express fast bowler
6. Fast-medium bowler
7. Medium pacer
8. Finger spinner
9. Wrist spinner

The original PNG masters and large nine-player source sheets are intentionally
excluded. Keep those archival files outside the deployed GitHub repository.

## Recommended repository location

Unzip this pack locally, then upload the individual folders to:

```text
assets/player-cards/nations/
├── afghanistan/
├── ireland/
├── netherlands/
├── pakistan/
├── sri_lanka/
└── zimbabwe/
```

Do not upload only the ZIP if the game must load these images. GitHub stores an
archive as one file and does not unpack it for the website.

Example HTML:

```html
<img
  src="assets/player-cards/nations/pakistan/pakistan_wrist_spinner.webp"
  alt="Pakistan wrist spinner"
  width="512"
  height="512"
  loading="lazy"
  decoding="async"
>
```

The optional `six_nations_overview.webp` is a visual reference sheet and does
not need to be loaded during normal gameplay.

